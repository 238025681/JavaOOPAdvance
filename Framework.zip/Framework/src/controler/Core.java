/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;



import IO.InputReadImpl;
import IO.WriterOutputImpl;
import controler.command.CommandDispatcher;
import interfaces.Executable;
import interfaces.WriterOutput;
import java.io.BufferedReader;
import java.io.IOException;

/**
 *
 * @author kalin
 */
public class Core {

    private BufferedReader reader;
    private boolean runnig;
    private CommandDispatcher dispatcher;
    private WriterOutput writerOutput;

    public Core() {
        this.setReader();
        this.setRunnig();
        this.setDispatcher();
        this.setWriterOutput();
    }

    public WriterOutput getWriterOutput() {
        return writerOutput;
    }

    private void setWriterOutput() {
        this.writerOutput = new WriterOutputImpl();
    }

    public BufferedReader getReader() {
        return reader;
    }

    private void setReader() {

        this.reader = new InputReadImpl().bufferedReader(System.in);
    }

    public boolean isRunnig() {
        return runnig;
    }

    private void setRunnig() {
        this.runnig = true;
    }

    public CommandDispatcher getDispatcher() {
        return dispatcher;
    }

    private void setDispatcher() {

        this.dispatcher = new CommandDispatcher(this);
    }



    public void run() throws IOException {

        while (runnig) {

            String[] token = reader.readLine().split("[ ,]+");
            
            if (token[0].equalsIgnoreCase("end")) {
                
                this.stop();
            }

            Executable command = this.getDispatcher().dispatch(token[0], token);

            String result = command.execute();

            if (result.equals("")) {
                
                continue;
            }

            this.getWriterOutput().print(result);

        }

        this.writerOutput.print(finalRsult());

    }

    public void stop() {

        this.runnig = false;
    }
    

    private String finalRsult() {

        StringBuilder sb = new StringBuilder();
        

        return sb.toString();
    }

}
