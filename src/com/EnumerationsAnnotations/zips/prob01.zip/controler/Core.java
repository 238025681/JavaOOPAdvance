/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;



import IO.InputReadImpl;
import IO.WriterOutputImpl;
import controler.command.CommandDispatcher;
import enumeration.CardSuit;
import interfaces.InputRead;
import interfaces.WriterOutput;
import java.io.IOException;

/**
 *
 * @author kalin
 */
public class Core {

    private InputRead reader;
    private boolean running;
    private CommandDispatcher dispatcher;
    private WriterOutput writerOutput;
    private CardSuit cardSuit;
    

    public Core() {
        this.setReader(new InputReadImpl());
        this.setRunning(true);
        this.setDispatcher(new CommandDispatcher(this));
        this.setWriterOutput(new WriterOutputImpl());
    }

    public WriterOutput getWriterOutput() {
        return writerOutput;
    }

    private void setWriterOutput(WriterOutput output) {
        this.writerOutput = output;
    }

    public InputRead getReader() {
        return reader;
    }

    private void setReader(InputRead reader) {

        this.reader = this.reader;
    }

    public boolean isRunning() {
        return running;
    }

    private void setRunning(boolean running) {
        this.running = running;
    }

    public CommandDispatcher getDispatcher() {
        return dispatcher;
    }

    private void setDispatcher(CommandDispatcher dispatcher) {

        this.dispatcher = dispatcher;
    }



    public void run() throws IOException {
        System.out.println("Card Suits:");
        for (CardSuit object : CardSuit.values()) {
            System.out.printf("Ordinal value: %s; Name value: %s%n", object.ordinal(), object);
        }
        

    }

    public void stop() {

        this.running = false;
    }
    

    private String finalRsult() {

        StringBuilder sb = new StringBuilder();
        

        return sb.toString();
    }

}
