/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enumeration;

/**
 *
 * @author kalin
 */
public enum CardSuit {
    
    CLUBS(0), 
   DIAMONDS(13), 
   HEARTS(26), 
    SPADES(39);
    
    public final int values;

    private CardSuit(int values) {
        this.values = values;
    }
    
    
    
}
