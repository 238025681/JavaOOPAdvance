
package models;

import enumeration.CardRank;
import enumeration.CardSuit;


public class Card {
    
    private CardSuit suit;
    private CardRank rank;

    public Card(CardSuit suit, CardRank rank) {
        this.suit = suit;
        this.rank = rank;
    }

    public CardSuit getSuit() {
        return suit;
    }

    private void setSuit(CardSuit suit) {
        this.suit = suit;
    }

    public CardRank getRank() {
        return rank;
    }

    private void setRank(CardRank rank) {
        this.rank = rank;
    }

   

    @Override
    public String toString() {
        return String.format("Card name: %s of %s; Card power: %d%n"
                    ,this.getRank()
                    ,this.getSuit(), this.getRank().value + this.getSuit().values);
    }
    
    
    
    
}
