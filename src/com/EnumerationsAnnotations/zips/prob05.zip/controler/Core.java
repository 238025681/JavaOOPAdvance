/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;



import IO.InputReadImpl;
import IO.WriterOutputImpl;
import controler.command.CommandDispatcher;
import enumeration.CardRank;
import enumeration.CardSuit;
import interfaces.InputRead;
import interfaces.WriterOutput;
import java.io.BufferedReader;
import java.io.IOException;
import models.Card;

/**
 *
 * @author kalin
 */
public class Core {

    private InputRead reader;
    private boolean running;
    private CommandDispatcher dispatcher;
    private WriterOutput writerOutput;
    

    public Core() {
        this.setReader(new InputReadImpl());
        this.setRunning(true);
        this.setDispatcher(new CommandDispatcher(this));
        this.setWriterOutput(new WriterOutputImpl());
    }

    public WriterOutput getWriterOutput() {
        return writerOutput;
    }

    private void setWriterOutput(WriterOutput output) {
        this.writerOutput = output;
    }

    public InputRead getReader() {
        return reader;
    }

    private void setReader(InputRead reader) {

        this.reader = reader;
    }

    public boolean isRunning() {
        return running;
    }

    private void setRunning(boolean running) {
        this.running = running;
    }

    public CommandDispatcher getDispatcher() {
        return dispatcher;
    }

    private void setDispatcher(CommandDispatcher dispatcher) {

        this.dispatcher = dispatcher;
    }



    public void run() throws IOException {
        
        BufferedReader bfr = reader.bufferedReader(System.in);

        CardRank cardRank = Enum.valueOf(CardRank.class, bfr.readLine());
        CardSuit cardSuit = Enum.valueOf(CardSuit.class, bfr.readLine());
        
        CardRank secondCardRank = Enum.valueOf(CardRank.class, bfr.readLine());
        CardSuit secondCardSuit = Enum.valueOf(CardSuit.class, bfr.readLine());
        
        Card card = new Card(cardSuit, cardRank);
        
        Card secondCard = new Card(secondCardSuit, secondCardRank);
        
        Card result = card.compareTo(secondCard) >= 0 ? card : secondCard;
        
        
        System.out.printf("%s%n", result);
    }

    public void stop() {

        this.running = false;
    }
    

    private String finalRsult() {

        StringBuilder sb = new StringBuilder();
        

        return sb.toString();
    }

}
