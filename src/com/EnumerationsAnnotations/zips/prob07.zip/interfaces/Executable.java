package interfaces;

/**
 *
 * @author kalin
 */
public interface Executable{

    String execute();
    
}
