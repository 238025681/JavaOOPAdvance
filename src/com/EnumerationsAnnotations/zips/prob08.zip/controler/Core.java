/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import IO.InputReadImpl;
import IO.WriterOutputImpl;
import controler.command.CommandDispatcher;
import exception.MyException;
import interfaces.Executable;
import interfaces.InputRead;
import interfaces.Player;
import interfaces.WriterOutput;
import java.io.BufferedReader;
import java.io.IOException;

/**
 *
 * @author kalin
 */
public class Core {

    private InputRead reader;
    private boolean running;
    private CommandDispatcher dispatcher;
    private WriterOutput writerOutput;
    private Database database;

    public Core() {

        this.setDatabase(new Database());
        this.setReader(new InputReadImpl());
        this.setRunning(true);
        this.setDispatcher(new CommandDispatcher(this.database));
        this.setWriterOutput(new WriterOutputImpl());

    }

    public WriterOutput getWriterOutput() {
        return writerOutput;
    }

    private void setWriterOutput(WriterOutput output) {
        this.writerOutput = output;
    }

    public InputRead getReader() {
        return reader;
    }

    private void setReader(InputRead reader) {

        this.reader = reader;
    }

    public boolean isRunning() {
        return running;
    }

    private void setRunning(boolean running) {
        this.running = running;
    }

    public CommandDispatcher getDispatcher() {
        return dispatcher;
    }

    private void setDispatcher(CommandDispatcher dispatcher) {

        this.dispatcher = dispatcher;
    }

    private void setDatabase(Database database) {
        this.database = database;
    }

    public void run() throws IOException {

        BufferedReader input = reader.bufferedReader(System.in);
        String result = "";
        int index = 0;

        while (running) {
            index++;
            String[] token = input.readLine().split("[\\s]+");

            if (token.length == 1) {
                
                Executable command = this.getDispatcher().dispatch("Create", token);
                result = command.execute();
                
            } else {
                
                Executable command = this.getDispatcher().dispatch("AddCard", token);

                try {
                    
                    result = command.execute();

                } catch (MyException e) {

                    System.out.println(e.getMessage());

                }
            }
            
            if (this.database.isLetsPlay()) {
                this.stop();
            }
           
            if (result.equals("")) {
                

                continue;
            }

            this.getWriterOutput().printNewLine(result);
            
          }
        
        this.getWriterOutput().print(finalRsult());

    }

    public void stop() {

        this.running = false;
    }

    private String finalRsult() {

        StringBuilder sb = new StringBuilder();
        Player winer = this.database.getPlayers().get(0).getHandOfCards().get(0).compareTo(
               
                this.database.getPlayers().get(1).getHandOfCards().get(0)) > 0 
              
                ? this.database.getPlayers().get(0) : this.database.getPlayers().get(1);

        return String.format("%s wins with %s", winer.getName(), winer.getHandOfCards().get(0));
    }

}
