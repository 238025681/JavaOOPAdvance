
package controler;

import enumeration.CardRank;
import enumeration.CardSuit;
import interfaces.Player;
import java.util.ArrayList;
import java.util.List;
import models.CardImpl;
import models.DeckOfCard;

/**
 *
 * @author kalin
 */
public class Database {
    
    private List< Player> players;
    private DeckOfCard cardDeck;
    private boolean letsPlay = false;

    public Database() {
        
        this.setCardDeck(new DeckOfCard());
        this.setPlayers(new ArrayList<>());
        this.generateDeck();
        
    }

    public boolean isLetsPlay() {
        return letsPlay;
    }

    public void setLetsPlay(boolean letsPlay) {
        this.letsPlay = letsPlay;
    }
    

    public List<Player> getPlayers() {
        return players;
    }

    private void setPlayers(List<Player> players) {
        this.players = players;
    }
    



    public DeckOfCard getCardDeck() {
        return cardDeck;
    }

    private void setCardDeck(DeckOfCard cardDeck) {
        this.cardDeck = cardDeck;
    }
    
    private void generateDeck(){
        for (CardSuit suits : CardSuit.values()) {
            
            for (CardRank rank : CardRank.values()) {
                this.getCardDeck().addCard(new CardImpl(suits, rank));
            }
        }
    }
    
}
