package controler.command;

import controler.Database;
import enumeration.CardRank;
import enumeration.CardSuit;
import exception.MyException;
import interfaces.Card;
import interfaces.Player;
import models.CardImpl;

/**
 *
 * @author kalin
 */
public class AddCardCommand extends Command {

    @Inject
    private String[] data;

    public AddCardCommand(Database database) {
        super(database);
    }

    @Override
    public String execute() {
        CardRank rank;
        CardSuit suit;
        try {
            rank = CardRank.valueOf(data[0]);
            suit = CardSuit.valueOf(data[2]);

            Card newCard = new CardImpl(suit, rank);

            this.getDatabase().getCardDeck().removeCard(newCard);
            Player playerOne = this.getDatabase().getPlayers().get(0);

            Player playerTwo = this.getDatabase().getPlayers().get(1);

            if (playerOne.getHandOfCards().size() < 5) {

                playerOne.addCard(newCard);

            } else{

                playerTwo.addCard(newCard);
                
            }
            
            
            if (playerTwo.getHandOfCards().size() == 5){
                
                this.getDatabase().setLetsPlay(true);

            }

        } catch (MyException e) {

            return e.getMessage();
        } catch (IllegalArgumentException e) {
            return "No such card exists.";
        }

        return "";
    }

}
