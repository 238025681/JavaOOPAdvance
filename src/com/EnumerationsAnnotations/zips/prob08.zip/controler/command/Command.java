/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler.command;

import controler.Database;
import interfaces.Executable;





/**
 *
 * @author kalin
 */
public abstract class Command implements Executable{
    
    private Database database;
    
    protected Command (Database database){
        
        this.setDatabase(database);
    }

    public Database getDatabase() {
        return database;
    }

    private void setDatabase(Database database) {
        this.database = database;
    }

    
    
    
}
