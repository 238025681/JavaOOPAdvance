/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler.command;

import controler.Database;
import interfaces.Player;
import models.PlayerImpl;

/**
 *
 * @author kalin
 */
public class CreateCommand extends Command{
    
    @Inject
    private String[] data;

    public CreateCommand(Database database) {
        super(database);
    }

    @Override
    public String execute() {
        
        Player newPlayer = new PlayerImpl(this.data[0]);
        
        this.getDatabase().getPlayers().add(newPlayer);
        
        return "";
    }
    
}
