package models;

import enumeration.CardRank;
import enumeration.CardSuit;
import interfaces.Card;

public class CardImpl implements Card {

    private CardSuit suit;
    private CardRank rank;

    public CardImpl(CardSuit suit, CardRank rank) {
        this.suit = suit;
        this.rank = rank;
    }

    @Override
    public CardSuit getSuit() {
        return suit;
    }

    private void setSuit(CardSuit suit) {
        this.suit = suit;
    }

    @Override
    public CardRank getRank() {
        return rank;
    }

    private void setRank(CardRank rank) {
        this.rank = rank;
    }

    @Override
    public int cardPower() {

        return this.getRank().value + this.getSuit().values;

    }

    @Override
    public String toString() {
        return String.format("%s of %s.%n", this.getRank(), this.getSuit());
    }

    @Override
    public int compareTo(Card card) {
        return Integer.compare(this.cardPower(), card.cardPower());
    }

    @Override
    public int compare(Card o1, Card o2) {
        return Integer.compare(o1.cardPower(), o2.cardPower());
    }
    
    @Override
    public int hashCode() {
        
        Integer fHashCode = 53;
        
                
        for (Character alphabet : this.getRank().toString().toCharArray()) {
            fHashCode += alphabet.hashCode();
        }
        
        return fHashCode + this.getSuit().hashCode();
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }

        if (!(obj instanceof Card)) {
            return false;
        }

        Card person = (Card) obj;

        if (!(this.getRank().toString().equals(person.getRank().toString()))) {
            return false;
        }
        
        
        if (!(this.getSuit().toString().equals(person.getSuit().toString()))) {
            return false;
        }

        return true;
    }

}
