package models;

import exception.MyException;
import interfaces.Card;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kalin
 */
public class DeckOfCard {

    private List<Card> cards;

    public DeckOfCard() {
        this.setCards(new ArrayList<>());
    }

    public List<Card> getCards() {
        return cards;
    }

    private void setCards(List<Card> cards) {
        this.cards = cards;
    }

    public void addCard(Card card) {

        this.cards.add(card);

    }

    public void removeCard(Card card) {
        
        if (!this.cards.remove(card)) {
          
            throw new MyException("Card is not in the deck.");
        }
      
    }

}
