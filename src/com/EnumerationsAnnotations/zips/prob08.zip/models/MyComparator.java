/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import interfaces.Card;
import java.util.Comparator;

/**
 *
 * @author kalin
 */
public class MyComparator implements Comparator<Card>{

    @Override
    public int compare(Card o1, Card o2) {
        
        return Integer.compare(o2.cardPower(), o1.cardPower());
    }
    
}
