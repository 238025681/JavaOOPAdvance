
package models;

import interfaces.Card;
import interfaces.Player;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;


public class PlayerImpl implements Player {
    
    private String name;
    private List<Card> handOfCards;

    public PlayerImpl(String name) {
        
        this.setName(name);
        
        this.setHandOfCards(new ArrayList<>());
    }

    private void setName(String name) {
        this.name = name;
    }

    private void setHandOfCards(List<Card> handOfCards) {
        this.handOfCards = handOfCards;
    }
    
    

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public List<Card>getHandOfCards() {
        Collections.sort(this.handOfCards, new MyComparator());
        return this.handOfCards;
    }

    @Override
    public void addCard(Card card) {
        
        this.handOfCards.add(card);
        
    }
    
}
