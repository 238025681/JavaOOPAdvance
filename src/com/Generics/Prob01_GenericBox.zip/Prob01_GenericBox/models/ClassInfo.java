
package com.Generics.Prob01_GenericBox.models;

/**
 *
 * @author chobi
 */
public class ClassInfo<T> {
    
    
    public static <T> void inputInfo(T element){
    
        System.out.println(element.getClass().getName().toString() + ": " + element);
    }
    
    
}
