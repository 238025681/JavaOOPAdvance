
package com.Interfaces.Prob04_Telephony.interfaces;


public interface Browsable {
    
    void brows(String... url);
}