package com.Interfaces.Prob04_Telephony.interfaces;

/**
 *
 * @author chobi
 */
public interface Callable {

    void makeCall(String... url); 

}
