package com.Interfaces.Prob05_BorderControl.interfaces;

public interface Migratable {

    public String getId();
}
