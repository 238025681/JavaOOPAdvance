
package com.Interfaces.Prob06_BirthdayCelebrations.interfaces;

/**
 *
 * @author chobi
 */
public interface Birthable {
    
    String getBirthdate();
    
}
