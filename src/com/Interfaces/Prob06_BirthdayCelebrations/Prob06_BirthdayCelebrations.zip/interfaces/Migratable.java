package com.Interfaces.Prob06_BirthdayCelebrations.interfaces;



public interface Migratable {

    public String getId();
}
