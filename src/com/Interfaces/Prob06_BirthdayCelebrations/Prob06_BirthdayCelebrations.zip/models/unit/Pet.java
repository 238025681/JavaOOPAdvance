/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Interfaces.Prob06_BirthdayCelebrations.models.unit;

/**
 *
 * @author chobi
 */
public class Pet extends BiologicUnit{
    
    public Pet(String name, String birthdate) {
        super(name, birthdate);
    }
    
   
    
}
