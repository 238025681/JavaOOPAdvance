package com.Interfaces.Prob07_FoodShortage.interfaces;



/**
 *
 * @author chobi
 */
public interface Birthable {
    
    String getBirthdate();
    
}
