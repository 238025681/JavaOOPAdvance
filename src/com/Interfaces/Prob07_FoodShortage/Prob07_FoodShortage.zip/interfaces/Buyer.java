package com.Interfaces.Prob07_FoodShortage.interfaces;

/**
 *
 * @author chobi
 */
public interface Buyer {
    
    void buyFood(); 
    int getFood();
}
