package com.Interfaces.Prob07_FoodShortage.interfaces;




public interface Migratable {

    public String getId();
}
