package com.Interfaces.Prob08_MilitaryElite.interfaces;

/**
 *
 * @author chobi
 */
public interface Identifiable {
    
    int getId();
   
    
}
