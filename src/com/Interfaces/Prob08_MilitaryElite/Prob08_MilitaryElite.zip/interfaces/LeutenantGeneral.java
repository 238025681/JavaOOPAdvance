
package com.Interfaces.Prob08_MilitaryElite.interfaces;

import java.util.List;

/**
 *
 * @author chobi
 */
public interface LeutenantGeneral extends Private{
    
    List<Private> getPrivates();
    
}
