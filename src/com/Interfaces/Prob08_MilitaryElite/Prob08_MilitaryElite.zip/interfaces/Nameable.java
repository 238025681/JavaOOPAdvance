package com.Interfaces.Prob08_MilitaryElite.interfaces;

/**
 *
 * @author chobi
 */
public interface Nameable {

    String getFirstname();

    String getLastName();

}
