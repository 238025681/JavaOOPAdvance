
package com.Interfaces.Prob08_MilitaryElite.interfaces;

/**
 *
 * @author chobi
 */
public interface Private extends Soldier, Payable{
    
}
