
package com.Interfaces.Prob08_MilitaryElite.interfaces;

/**
 *
 * @author chobi
 */
public interface Soldier extends Nameable, Identifiable{
    
}
