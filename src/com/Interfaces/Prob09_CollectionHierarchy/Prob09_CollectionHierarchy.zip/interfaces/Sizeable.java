
package com.Interfaces.Prob09_CollectionHierarchy.interfaces;

/**
 *
 * @author chobi
 */
public interface Sizeable extends Removeable{
    
    Integer used();
    
}
