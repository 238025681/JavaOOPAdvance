
package com.IteratorsAndComparators.Prob03_StackIterator;

import com.IteratorsAndComparators.Prob03_StackIterator.controler.Core;
import java.io.IOException;

/**
 *
 * @author kalin
 */
public class Main {
    public static void main(String[] args) throws IOException {
        
        Core core = new Core();
        
        core.run();
        
    }
    
}
