package com.IteratorsAndComparators.Prob04_Froggy;

import com.IteratorsAndComparators.Prob04_Froggy.controler.Core;

import java.io.IOException;

/**
 *
 * @author kalin
 */
public class Main {

    public static void main(String[] args) throws IOException {

        Core core = new Core();

        core.run();

    }

}
