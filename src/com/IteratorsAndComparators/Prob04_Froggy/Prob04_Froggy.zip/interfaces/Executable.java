package com.IteratorsAndComparators.Prob04_Froggy.interfaces;

/**
 *
 * @author kalin
 */
public interface Executable{

    String execute();
    
}
