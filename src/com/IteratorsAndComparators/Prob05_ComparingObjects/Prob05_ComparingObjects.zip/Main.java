package com.IteratorsAndComparators.Prob05_ComparingObjects;



import com.IteratorsAndComparators.Prob05_ComparingObjects.controler.Core;
import java.io.IOException;

/**
 *
 * @author kalin
 */
public class Main {
    public static void main(String[] args) throws IOException {
        
        Core core = new Core();
       
            core.run();
               
    }

        
}
