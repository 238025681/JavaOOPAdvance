package com.IteratorsAndComparators.Prob05_ComparingObjects.interfaces;

/**
 *
 * @author kalin
 */
public interface Executable{

    String execute();
    
}
